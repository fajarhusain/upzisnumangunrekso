<h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
    {{ $slot }}
</h2>
