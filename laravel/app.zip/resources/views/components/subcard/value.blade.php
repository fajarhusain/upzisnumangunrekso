<h2 class="text-lg font-medium text-indigo-500">
    {{ $slot }}
</h2>
