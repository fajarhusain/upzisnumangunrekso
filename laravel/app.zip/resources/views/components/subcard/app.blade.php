<div class="bg-gray-100 dark:bg-gray-700 rounded-lg p-4 flex flex-col justify-between">
    {{ $slot }}
</div>