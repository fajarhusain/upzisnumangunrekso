<h2 class="text-lg font-medium text-gray-900 dark:text-gray-100 py-1 pb-3">
    {{ $slot }}
</h2>
