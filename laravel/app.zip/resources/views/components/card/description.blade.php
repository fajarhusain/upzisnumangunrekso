<p class="text-sm text-gray-600 dark:text-gray-400 w-full">
    {{ $slot }}
</p>
