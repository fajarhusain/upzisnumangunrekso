<p class="text-sm text-gray-600 dark:text-gray-400 w-full">
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\Users\FAJARHUSAINASYARI\Pictures\upzismangunrekso\resources\views/components/card/description.blade.php ENDPATH**/ ?>