<?php if (isset($component)) { $__componentOriginal1b2476b6943162f58b3ccc47e91e30c2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b2476b6943162f58b3ccc47e91e30c2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal6ea0bfee1a50e1de1096e35e7b344cad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6ea0bfee1a50e1de1096e35e7b344cad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php echo e(__('Tabel Fundraising')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6ea0bfee1a50e1de1096e35e7b344cad)): ?>
<?php $attributes = $__attributesOriginal6ea0bfee1a50e1de1096e35e7b344cad; ?>
<?php unset($__attributesOriginal6ea0bfee1a50e1de1096e35e7b344cad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6ea0bfee1a50e1de1096e35e7b344cad)): ?>
<?php $component = $__componentOriginal6ea0bfee1a50e1de1096e35e7b344cad; ?>
<?php unset($__componentOriginal6ea0bfee1a50e1de1096e35e7b344cad); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal687b2b57c91035c27980e0099398a14b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal687b2b57c91035c27980e0099398a14b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card.description','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card.description'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="flex gap-4 text-black dark:text-white">
            <p>Target Tahun ini: Rp.</p>
            <p><?php echo e(number_format($targetselectedTahun, 0, ',', '.')); ?></p>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal687b2b57c91035c27980e0099398a14b)): ?>
<?php $attributes = $__attributesOriginal687b2b57c91035c27980e0099398a14b; ?>
<?php unset($__attributesOriginal687b2b57c91035c27980e0099398a14b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal687b2b57c91035c27980e0099398a14b)): ?>
<?php $component = $__componentOriginal687b2b57c91035c27980e0099398a14b; ?>
<?php unset($__componentOriginal687b2b57c91035c27980e0099398a14b); ?>
<?php endif; ?>
    <div class="relative mt-6 overflow-auto rounded-md">
        <table class="w-full text-base text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-lg">
            <thead class="text-sm text-white uppercase bg-green-600 dark:bg-green-800">
                <tr>
                    <th class="px-4 py-3 text-center border border-gray-400 dark:border-gray-700">No.</th>
                    <th class="px-6 py-3 border border-gray-400 dark:border-gray-700">Nama Akun</th>
                    <th class="px-6 py-3 text-center border border-gray-400 dark:border-gray-700">Target</th>
                    <th class="px-6 py-3 text-center border border-gray-400 dark:border-gray-700">Realisasi</th>
                    <th class="px-6 py-3 text-center border border-gray-400 dark:border-gray-700">Realisasi sub Pilar</th>
                </tr>
            </thead>
            <tbody>
                <tr class="bg-green-100 dark:bg-green-900 font-semibold">
                    <td rowspan="2"></td>
                    <td rowspan="2" class="px-6 py-4">Zakat (<?php echo e($targetPersenZakat); ?>%)</td>
                    <td class="px-6 py-4 text-right">Rp. <?php echo e(number_format($nominalTargetZakat, 0, ',', '.')); ?></td>
                    <td class="px-6 py-4 text-center"><?php echo e($pembulatanPersenRealisaiZakat); ?>%</td>
                    <td></td>
                </tr>
                <tr class="bg-green-50 dark:bg-green-800">
                    <td colspan="3" class="px-6 py-4 text-right">Rp. <?php echo e(number_format($totalRealisasiZakat, 0, ',', '.')); ?></td>
                </tr>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sumberZakats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sumberZakat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.fundraising-per-program-sumber', ['selectedTahun' => $this->selectedTahun,'programSumber' => $sumberZakat,'nominalTargetInduk' => $nominalTargetZakat]);

$__html = app('livewire')->mount($__name, $__params, $sumberZakat->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                <tr class="bg-green-200 dark:bg-green-700 font-bold">
                    <td></td>
                    <td>Total</td>
                    <td class="px-6 py-4 text-right">Rp. <?php echo e(number_format($nominalTargetZakat, 0, ',', '.')); ?></td>
                    <td></td>
                    <td class="px-6 py-4 text-right">Rp. <?php echo e(number_format($totalRealisasiZakat, 0, ',', '.')); ?></td>
                </tr>
                
                <tr class="bg-blue-100 dark:bg-blue-900 font-semibold">
                    <td></td>
                    <td>Infaq (<?php echo e($targetPersenInfaq); ?>%)</td>
                    <td class="px-6 py-4 text-right">Rp. <?php echo e(number_format($nominalTargetInfaq, 0, ',', '.')); ?></td>
                    <td class="px-6 py-4 text-center"><?php echo e($pembulatanPersenRealisaiInfaq); ?>%</td>
                    <td></td>
                </tr>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sumberInfaqNonRutins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sumberInfaqNonRutin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.fundraising-per-program-sumber', ['selectedTahun' => $this->selectedTahun,'programSumber' => $sumberInfaqNonRutin,'nominalTargetInduk' => $nominalTargetInfaqNonRutin]);

$__html = app('livewire')->mount($__name, $__params, $sumberInfaqNonRutin->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                <tr class="bg-blue-200 dark:bg-blue-700 font-bold">
                    <td></td>
                    <td>Total</td>
                    <td class="px-6 py-4 text-right">Rp. <?php echo e(number_format($nominalTargetInfaqNonRutin, 0, ',', '.')); ?></td>
                    <td></td>
                    <td class="px-6 py-4 text-right">Rp. <?php echo e(number_format($totalRealisasiInfaqNonRutin, 0, ',', '.')); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b2476b6943162f58b3ccc47e91e30c2)): ?>
<?php $attributes = $__attributesOriginal1b2476b6943162f58b3ccc47e91e30c2; ?>
<?php unset($__attributesOriginal1b2476b6943162f58b3ccc47e91e30c2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b2476b6943162f58b3ccc47e91e30c2)): ?>
<?php $component = $__componentOriginal1b2476b6943162f58b3ccc47e91e30c2; ?>
<?php unset($__componentOriginal1b2476b6943162f58b3ccc47e91e30c2); ?>
<?php endif; ?>
<?php /**PATH C:\Users\FAJARHUSAINASYARI\Pictures\upzismangunrekso\resources\views/livewire/dashboard/table-fundraising.blade.php ENDPATH**/ ?>