<?php if (isset($component)) { $__componentOriginal1b2476b6943162f58b3ccc47e91e30c2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b2476b6943162f58b3ccc47e91e30c2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="justify-between w-full md:flex">
        <?php if (isset($component)) { $__componentOriginal6ea0bfee1a50e1de1096e35e7b344cad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6ea0bfee1a50e1de1096e35e7b344cad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php echo e(__('Target Program')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6ea0bfee1a50e1de1096e35e7b344cad)): ?>
<?php $attributes = $__attributesOriginal6ea0bfee1a50e1de1096e35e7b344cad; ?>
<?php unset($__attributesOriginal6ea0bfee1a50e1de1096e35e7b344cad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6ea0bfee1a50e1de1096e35e7b344cad)): ?>
<?php $component = $__componentOriginal6ea0bfee1a50e1de1096e35e7b344cad; ?>
<?php unset($__componentOriginal6ea0bfee1a50e1de1096e35e7b344cad); ?>
<?php endif; ?>
        <div class="flex flex-wrap gap-2">
            <?php if (isset($component)) { $__componentOriginal40922ffb43906770eb4ad2d3d9ae0638 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal40922ffb43906770eb4ad2d3d9ae0638 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button.link-secondary','data' => ['href' => ''.e(route('targetprogrampilar.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button.link-secondary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('targetprogrampilar.index')).'']); ?>
                <?php echo e(__('Manage Target Program')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal40922ffb43906770eb4ad2d3d9ae0638)): ?>
<?php $attributes = $__attributesOriginal40922ffb43906770eb4ad2d3d9ae0638; ?>
<?php unset($__attributesOriginal40922ffb43906770eb4ad2d3d9ae0638); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40922ffb43906770eb4ad2d3d9ae0638)): ?>
<?php $component = $__componentOriginal40922ffb43906770eb4ad2d3d9ae0638; ?>
<?php unset($__componentOriginal40922ffb43906770eb4ad2d3d9ae0638); ?>
<?php endif; ?>
        </div>
    </div>
    <div class="relative mt-6 overflow-x-visible overflow-y-visible rounded-md md:block">
        <table class="w-full text-base text-left text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-100 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3">
                        <?php echo e(__('No.')); ?>

                    </th>
                    <th scope="col" class="px-6 py-3 lg:table-cell">
                        <?php echo e(__('Program')); ?>

                    </th>
                    <th scope="col" class="px-6 py-3 lg:table-cell">
                        <?php echo e(__('Persentage')); ?>

                    </th>
                        <th scope="col" class="px-6 py-3 lg:table-cell">
                        <?php echo e(__('Tahun')); ?>

                    </th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $targetProgramPilars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $targetProgramPilar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="odd:bg-white odd:dark:bg-gray-800 even:bg-gray-100 even:dark:bg-gray-700">
                    <td scope="row" class="px-6 py-4 font-medium text-gray-900 dark:text-gray-200">
                        
                        <div class="flex">
                            <div class="hover:underline whitespace-nowrap">
                                <?php echo e($loop->iteration); ?>

                            </div>
                        </div>
                    </td>

                    <td class="px-6 py-4 lg:table-cell">
                        <div class="flex">
                            <p>
                                <?php echo e($targetProgramPilar->programPilar->name ?? '-'); ?>

                            </p>
                        </div>
                    </td>

                    <td x-data="{nominal: <?php echo e($targetProgramPilar->nominal); ?>}"
                        class="px-6 py-4 lg:table-cell">
                        <div class="flex">
                            <p x-text="nominal.toString()+' %'"></p>
                        </div>
                    </td>

                    <td class="px-6 py-4 lg:table-cell">
                        <div class="flex">
                            <?php echo e($targetProgramPilar->tahun->name ?? '-'); ?>

                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr class="bg-white dark:bg-gray-800">
                    <td scope="row" class="px-6 py-4 font-medium text-gray-900 dark:text-gray-200">
                        Empty
                    </td>
            </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b2476b6943162f58b3ccc47e91e30c2)): ?>
<?php $attributes = $__attributesOriginal1b2476b6943162f58b3ccc47e91e30c2; ?>
<?php unset($__attributesOriginal1b2476b6943162f58b3ccc47e91e30c2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b2476b6943162f58b3ccc47e91e30c2)): ?>
<?php $component = $__componentOriginal1b2476b6943162f58b3ccc47e91e30c2; ?>
<?php unset($__componentOriginal1b2476b6943162f58b3ccc47e91e30c2); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\LazismuUMY-main\LazismuUMY-main\resources\views/livewire/target/target-program-pilar.blade.php ENDPATH**/ ?>