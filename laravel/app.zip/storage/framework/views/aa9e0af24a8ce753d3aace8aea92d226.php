
<img src="<?php echo e(asset('logo/Logo_Lazismu_UMY_dark.png')); ?>" alt="Logo UpzisNU Mangunrekso"
    <?php echo e($attributes->merge([
        'class' => 'hidden dark:block',
    ])); ?>>

<img src="<?php echo e(asset('logo/zisnu.png')); ?>" alt="Logo UpzisNU Mangunrekso"
    <?php echo e($attributes->merge([
        'class' => 'dark:hidden',
    ])); ?>>
<?php /**PATH C:\xampp\htdocs\LazismuUMY-main\LazismuUMY-main\resources\views/components/application-logo.blade.php ENDPATH**/ ?>