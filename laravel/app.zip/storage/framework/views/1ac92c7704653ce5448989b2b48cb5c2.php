<p class="text-sm text-gray-600 dark:text-gray-400 w-full">
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\xampp\htdocs\LazismuUMY-main\LazismuUMY-main\resources\views/components/card/description.blade.php ENDPATH**/ ?>