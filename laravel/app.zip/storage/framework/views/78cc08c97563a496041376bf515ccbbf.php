<h2 class="text-lg font-medium text-gray-900 dark:text-gray-100 py-1 pb-3">
    <?php echo e($slot); ?>

</h2>
<?php /**PATH C:\xampp\htdocs\LazismuUMY-main\LazismuUMY-main\resources\views/components/card/title.blade.php ENDPATH**/ ?>