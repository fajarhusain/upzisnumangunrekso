<div>
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sumberDanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sumberDana): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.saldo-per-sumber-dana', ['selectedTahun' => $this->selectedTahun,'sumberDana' => $sumberDana,'sumberDonasi' => $this->sumberDonasi]);

$__html = app('livewire')->mount($__name, $__params, $sumberDana->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Users\FAJARHUSAINASYARI\Pictures\upzismangunrekso\resources\views/livewire/dashboard/saldo-per-sumber-donasi.blade.php ENDPATH**/ ?>