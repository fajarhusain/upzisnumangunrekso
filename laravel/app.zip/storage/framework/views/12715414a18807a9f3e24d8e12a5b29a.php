<tr class="odd:bg-white odd:dark:bg-gray-800 even:bg-gray-100 even:dark:bg-gray-700">
    <td class="justify-center w-2 py-4 pl-6 font-medium text-gray-900 dark:text-gray-200">
        <?php echo e($programSumber->index); ?>

    </td>
    <td class="px-6 py-4 lg:table-cell">
        <?php echo e($programSumber->name); ?>(<?php echo e($persenTargetProSum); ?>%)
    </td>
    <td wire:key="nominal-<?php echo e($nominalTargetProSum); ?>" x-data="{ nominal: <?php echo e($nominalTargetProSum); ?> }" class="px-6 py-4 lg:table-cell min-w-44">
        <div class="flex justify-between">
            <p>Rp.</p>
            <p x-text="nominal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')"></p>
        </div>
    </td>
    <td wire:key="nominal-<?php echo e($nominalRealisasiProSum); ?>" x-data="{ nominal: <?php echo e($nominalRealisasiProSum); ?> }" class="px-6 py-4 lg:table-cell min-w-44">
        <div class="flex justify-between">
            <p>Rp.</p>
            <p x-text="nominal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')"></p>
        </div>
    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\LazismuUMY-main\LazismuUMY-main\resources\views/livewire/dashboard/fundraising-per-program-sumber.blade.php ENDPATH**/ ?>