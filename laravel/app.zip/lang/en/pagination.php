<?php

declare(strict_types=1);

return [
    'next' => 'Next &raquo;',
    'previous' => '&laquo; Previous',
    'to' => 'to',
    'of' => 'of',
    'results' => 'results',
    'showing' => 'Showing',
];
